package com.dashboad.hystrix_dashboad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixDashboadApplicationTests {

	@Test
	void contextLoads() {
	}

}
