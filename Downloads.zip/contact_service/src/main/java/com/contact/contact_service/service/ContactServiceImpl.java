package com.contact.contact_service.service;

import com.contact.contact_service.entity.Contact;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class ContactServiceImpl implements ContactService{

    List<Contact> list = List.of(
            new Contact(101L, "A@gmail.com", "A", 1L),
            new Contact(102L, "B@gmail.com", "B", 1L),
            new Contact(103L, "C@gmail.com", "C", 2L),
            new Contact(104L, "D@gmail.com", "D", 3L)
    );
    @Override
    public List<Contact> getContactsOfUser(Long userId) {
        return list.stream().filter(contact -> contact.getUserId().equals(userId)).collect(Collectors.toList());
    }
}
