package com.user.user_service.service;

import com.user.user_service.entity.User;

import java.util.List;

public class UserServiceImpl implements UserService {
    List<User> list = List.of(
            new User(1L, "Deep", "12131415"),
            new User(2L, "Ishu", "16171819"),
            new User(3L, "Shivam", "20212223")
    );
    @Override
    public User getUser(Long Id) {
        return this.list.stream().filter(user -> user.getUserId().equals(Id)).findAny().orElse(null);
    }
}
