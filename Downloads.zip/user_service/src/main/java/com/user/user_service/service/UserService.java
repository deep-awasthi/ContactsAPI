package com.user.user_service.service;

import com.user.user_service.entity.User;

public interface UserService {
    public User getUser(Long Id);

}
